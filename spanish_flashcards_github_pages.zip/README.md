# Spanish Flashcards (iPad-friendly)

Single-file HTML app. Host from the repository root and enable **GitHub Pages** (Deploy from a branch, `main`, folder `/ (root)`).

Open it on iPad in Safari and optionally **Add to Home Screen**.
